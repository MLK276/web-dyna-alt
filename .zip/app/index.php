<?php
include "header.php";
?>

<table border=0 cellspacing=0 cellpadding=0>
 <tr>
  <td width=75>
  <p><img width=75 height=75
  src="images/mob.png"></p>
  </td>
  <td width=400>

<h2>Bienvenue&nbsp;!</h2>

  <p>Cette application vous permet de gérer vos flashmobs.</p>


<a href="./flashmobs"><input type="button" value="Liste des flash-mobs" class="bouton1"></a>
<a href="./flashmobs/create"><input type="button" value="+ Créer une flash-mob" class="bouton2"></a>

  </td>
 </tr>
</table>


<?php
include "footer.php";
?>