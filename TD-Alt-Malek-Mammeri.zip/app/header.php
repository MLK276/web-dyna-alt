<!DOCTYPE html>
<html lang="fr">
<head>
	<title><TP4></title>
	<meta charset="utf-8">
	<meta name="description" content="TP4">
	<meta name="author" content="Malek Mammeri">
	
<style>
.bouton1{
background-color: #21ba45;
color: white;
padding: 10px;
border: none;
}
.bouton2{
background-color: #00b5ad;
color: white;
padding: 10px;
border: none;
}
</style> 

</head>
<body>

<?php
echo '<img src="images/logo.png" border="0" /></div> ';
?>